package com.alimazon.air;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlimazonAirApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlimazonAirApplication.class, args);
	}

}

